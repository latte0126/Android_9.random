package com.example.a9random;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    int x;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView confirm = (TextView)findViewById(R.id.textView);
        Intent intent = getIntent();
        int button = intent.getIntExtra("A_EXTRA",0);
        int num = intent.getIntExtra("B_EXTRA",0);
        confirm.setText(""+num+button);
        x=num;

        if(button>num) {
            confirm.setText("猜太大了\n猜小一點");

        }
        else if (button<num) {
            confirm.setText("猜太小了\n猜大一點");
        }
        else {
            confirm.setText("正確");
            x=0;
        }
    }

    public void back(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("C_EXTRA", x );
        startActivity(intent);
    }
}