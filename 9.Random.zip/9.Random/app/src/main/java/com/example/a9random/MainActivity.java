package com.example.a9random;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private  int Button,Num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        int num = intent.getIntExtra("C_EXTRA",0);

        if (num==0)
            Num = (int) (Math.random() * 9 + 1);
        else
            Num=intent.getIntExtra("C_EXTRA",0);
        intent.putExtra("B_EXTRA", Num );

    }
    public void start(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        Num = (int) (Math.random() * 9 + 1);
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);
    }

    public void a1(View view) {
        Button=1;
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);


    }

    public void a2(View view) {
        Button=2;
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);

    }

    public void a3(View view) {
        Button=3;

        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);

    }

    public void a4(View view) {
        Button=4;

        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);

    }

    public void a5(View view) {
        Button=5;

        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);

    }

    public void a6(View view) {
        Button=6;
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);

    }

    public void a7(View view) {
        Button=7;

        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);

    }

    public void a8(View view) {
        Button=8;
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);

    }

    public void a9(View view) {
        Button=9;
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("A_EXTRA", Button );
        intent.putExtra("B_EXTRA", Num );
        startActivity(intent);

    }


}